--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "BestKind";
--
-- Name: BestKind; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "BestKind" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "BestKind" OWNER TO postgres;

\connect "BestKind"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    saleid integer NOT NULL,
    beerid integer NOT NULL,
    salesrepid integer NOT NULL,
    locationid integer NOT NULL,
    saleamount numeric NOT NULL,
    saledate date NOT NULL,
    customerid integer
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- Name: sales_saleid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_saleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_saleid_seq OWNER TO postgres;

--
-- Name: sales_saleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_saleid_seq OWNED BY public.sales.saleid;


--
-- Name: sales saleid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales ALTER COLUMN saleid SET DEFAULT nextval('public.sales_saleid_seq'::regclass);


--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (saleid, beerid, salesrepid, locationid, saleamount, saledate, customerid) FROM stdin;
\.
COPY public.sales (saleid, beerid, salesrepid, locationid, saleamount, saledate, customerid) FROM '$$PATH$$/3622.dat';

--
-- Name: sales_saleid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_saleid_seq', 1, true);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (saleid);


--
-- Name: sales fk_sales_beerid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT fk_sales_beerid FOREIGN KEY (beerid) REFERENCES public.beers(beerid);


--
-- Name: sales fk_sales_customerid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT fk_sales_customerid FOREIGN KEY (customerid) REFERENCES public.customers(customerid);


--
-- Name: sales fk_sales_locationid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT fk_sales_locationid FOREIGN KEY (locationid) REFERENCES public.locations(locationid);


--
-- Name: sales fk_sales_salesrepid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT fk_sales_salesrepid FOREIGN KEY (salesrepid) REFERENCES public.salesreps(salesrepid);


--
-- PostgreSQL database dump complete
--

