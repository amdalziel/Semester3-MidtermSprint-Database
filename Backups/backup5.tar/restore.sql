--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "BKB";
--
-- Name: BKB; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "BKB" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "BKB" OWNER TO postgres;

\connect "BKB"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Beer; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Beer" (
    beer_id integer NOT NULL,
    beer_name character varying(100),
    beer_type character varying(100),
    price_single numeric,
    price_bucket numeric
);


ALTER TABLE public."Beer" OWNER TO postgres;

--
-- Name: Beer_beer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Beer_beer_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Beer_beer_id_seq" OWNER TO postgres;

--
-- Name: Beer_beer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Beer_beer_id_seq" OWNED BY public."Beer".beer_id;


--
-- Name: Customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Customers" (
    customer_id integer NOT NULL,
    name character varying(100) NOT NULL,
    email character varying(100) NOT NULL,
    address character varying(100) NOT NULL,
    phone character varying(100) NOT NULL,
    created_at date
);


ALTER TABLE public."Customers" OWNER TO postgres;

--
-- Name: Customers_customer_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Customers_customer_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Customers_customer_id_seq" OWNER TO postgres;

--
-- Name: Customers_customer_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Customers_customer_id_seq" OWNED BY public."Customers".customer_id;


--
-- Name: Deliveries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Deliveries" (
    delivery_id integer NOT NULL,
    amount_delivered integer,
    beer_id integer,
    delivery_date date,
    customer_id integer NOT NULL
);


ALTER TABLE public."Deliveries" OWNER TO postgres;

--
-- Name: Deliveries_delivery_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Deliveries_delivery_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Deliveries_delivery_id_seq" OWNER TO postgres;

--
-- Name: Deliveries_delivery_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Deliveries_delivery_id_seq" OWNED BY public."Deliveries".delivery_id;


--
-- Name: Locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Locations" (
    location_id integer NOT NULL,
    location_name character varying(100) NOT NULL,
    location_type character varying(100) NOT NULL
);


ALTER TABLE public."Locations" OWNER TO postgres;

--
-- Name: Locations_location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Locations_location_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Locations_location_id_seq" OWNER TO postgres;

--
-- Name: Locations_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Locations_location_id_seq" OWNED BY public."Locations".location_id;


--
-- Name: Recycling; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Recycling" (
    recycling_id integer NOT NULL,
    recycling_can_kg integer,
    recycling_bucket_kg integer,
    pickup_date date,
    delivery_id integer
);


ALTER TABLE public."Recycling" OWNER TO postgres;

--
-- Name: Recycling_recycling_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Recycling_recycling_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Recycling_recycling_id_seq" OWNER TO postgres;

--
-- Name: Recycling_recycling_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Recycling_recycling_id_seq" OWNED BY public."Recycling".recycling_id;


--
-- Name: Rewards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Rewards" (
    reward_id integer NOT NULL,
    customer_id integer,
    amount_spent numeric,
    reward_points integer
);


ALTER TABLE public."Rewards" OWNER TO postgres;

--
-- Name: Rewards_reward_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Rewards_reward_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Rewards_reward_id_seq" OWNER TO postgres;

--
-- Name: Rewards_reward_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Rewards_reward_id_seq" OWNED BY public."Rewards".reward_id;


--
-- Name: Sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Sales" (
    sale_id integer NOT NULL,
    beer_id integer,
    salesrep_id integer,
    location_id integer,
    customer_id integer,
    sale_amount numeric,
    sale_date date
);


ALTER TABLE public."Sales" OWNER TO postgres;

--
-- Name: SalesReps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."SalesReps" (
    salesrep_id integer NOT NULL,
    rep_name character varying,
    total_sales integer,
    rep_awards character varying(100)
);


ALTER TABLE public."SalesReps" OWNER TO postgres;

--
-- Name: SalesReps_salesrep_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."SalesReps_salesrep_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."SalesReps_salesrep_id_seq" OWNER TO postgres;

--
-- Name: SalesReps_salesrep_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."SalesReps_salesrep_id_seq" OWNED BY public."SalesReps".salesrep_id;


--
-- Name: Sales_sale_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Sales_sale_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public."Sales_sale_id_seq" OWNER TO postgres;

--
-- Name: Sales_sale_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Sales_sale_id_seq" OWNED BY public."Sales".sale_id;


--
-- Name: Beer beer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Beer" ALTER COLUMN beer_id SET DEFAULT nextval('public."Beer_beer_id_seq"'::regclass);


--
-- Name: Customers customer_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customers" ALTER COLUMN customer_id SET DEFAULT nextval('public."Customers_customer_id_seq"'::regclass);


--
-- Name: Deliveries delivery_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Deliveries" ALTER COLUMN delivery_id SET DEFAULT nextval('public."Deliveries_delivery_id_seq"'::regclass);


--
-- Name: Locations location_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Locations" ALTER COLUMN location_id SET DEFAULT nextval('public."Locations_location_id_seq"'::regclass);


--
-- Name: Recycling recycling_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recycling" ALTER COLUMN recycling_id SET DEFAULT nextval('public."Recycling_recycling_id_seq"'::regclass);


--
-- Name: Rewards reward_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Rewards" ALTER COLUMN reward_id SET DEFAULT nextval('public."Rewards_reward_id_seq"'::regclass);


--
-- Name: Sales sale_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales" ALTER COLUMN sale_id SET DEFAULT nextval('public."Sales_sale_id_seq"'::regclass);


--
-- Name: SalesReps salesrep_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SalesReps" ALTER COLUMN salesrep_id SET DEFAULT nextval('public."SalesReps_salesrep_id_seq"'::regclass);


--
-- Data for Name: Beer; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Beer" (beer_id, beer_name, beer_type, price_single, price_bucket) FROM stdin;
\.
COPY public."Beer" (beer_id, beer_name, beer_type, price_single, price_bucket) FROM '$$PATH$$/3652.dat';

--
-- Data for Name: Customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Customers" (customer_id, name, email, address, phone, created_at) FROM stdin;
\.
COPY public."Customers" (customer_id, name, email, address, phone, created_at) FROM '$$PATH$$/3654.dat';

--
-- Data for Name: Deliveries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Deliveries" (delivery_id, amount_delivered, beer_id, delivery_date, customer_id) FROM stdin;
\.
COPY public."Deliveries" (delivery_id, amount_delivered, beer_id, delivery_date, customer_id) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: Locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Locations" (location_id, location_name, location_type) FROM stdin;
\.
COPY public."Locations" (location_id, location_name, location_type) FROM '$$PATH$$/3658.dat';

--
-- Data for Name: Recycling; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Recycling" (recycling_id, recycling_can_kg, recycling_bucket_kg, pickup_date, delivery_id) FROM stdin;
\.
COPY public."Recycling" (recycling_id, recycling_can_kg, recycling_bucket_kg, pickup_date, delivery_id) FROM '$$PATH$$/3660.dat';

--
-- Data for Name: Rewards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Rewards" (reward_id, customer_id, amount_spent, reward_points) FROM stdin;
\.
COPY public."Rewards" (reward_id, customer_id, amount_spent, reward_points) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: Sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Sales" (sale_id, beer_id, salesrep_id, location_id, customer_id, sale_amount, sale_date) FROM stdin;
\.
COPY public."Sales" (sale_id, beer_id, salesrep_id, location_id, customer_id, sale_amount, sale_date) FROM '$$PATH$$/3664.dat';

--
-- Data for Name: SalesReps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."SalesReps" (salesrep_id, rep_name, total_sales, rep_awards) FROM stdin;
\.
COPY public."SalesReps" (salesrep_id, rep_name, total_sales, rep_awards) FROM '$$PATH$$/3665.dat';

--
-- Name: Beer_beer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Beer_beer_id_seq"', 10, true);


--
-- Name: Customers_customer_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Customers_customer_id_seq"', 19, true);


--
-- Name: Deliveries_delivery_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Deliveries_delivery_id_seq"', 80, true);


--
-- Name: Locations_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Locations_location_id_seq"', 7, true);


--
-- Name: Recycling_recycling_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Recycling_recycling_id_seq"', 80, true);


--
-- Name: Rewards_reward_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Rewards_reward_id_seq"', 19, true);


--
-- Name: SalesReps_salesrep_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."SalesReps_salesrep_id_seq"', 7, true);


--
-- Name: Sales_sale_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Sales_sale_id_seq"', 80, true);


--
-- Name: Beer Beer_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Beer"
    ADD CONSTRAINT "Beer_pkey" PRIMARY KEY (beer_id);


--
-- Name: Customers Customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Customers"
    ADD CONSTRAINT "Customers_pkey" PRIMARY KEY (customer_id);


--
-- Name: Deliveries Deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Deliveries"
    ADD CONSTRAINT "Deliveries_pkey" PRIMARY KEY (delivery_id);


--
-- Name: Locations Locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Locations"
    ADD CONSTRAINT "Locations_pkey" PRIMARY KEY (location_id);


--
-- Name: Recycling Recycling_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recycling"
    ADD CONSTRAINT "Recycling_pkey" PRIMARY KEY (recycling_id);


--
-- Name: Rewards Rewards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Rewards"
    ADD CONSTRAINT "Rewards_pkey" PRIMARY KEY (reward_id);


--
-- Name: SalesReps SalesReps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."SalesReps"
    ADD CONSTRAINT "SalesReps_pkey" PRIMARY KEY (salesrep_id);


--
-- Name: Sales Sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales"
    ADD CONSTRAINT "Sales_pkey" PRIMARY KEY (sale_id);


--
-- Name: Sales beer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales"
    ADD CONSTRAINT beer_id FOREIGN KEY (beer_id) REFERENCES public."Beer"(beer_id) NOT VALID;


--
-- Name: Deliveries customer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Deliveries"
    ADD CONSTRAINT customer_id FOREIGN KEY (customer_id) REFERENCES public."Customers"(customer_id) NOT VALID;


--
-- Name: Rewards customer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Rewards"
    ADD CONSTRAINT customer_id FOREIGN KEY (customer_id) REFERENCES public."Customers"(customer_id) NOT VALID;


--
-- Name: Sales customer_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales"
    ADD CONSTRAINT customer_id FOREIGN KEY (customer_id) REFERENCES public."Customers"(customer_id) NOT VALID;


--
-- Name: Recycling delivery_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Recycling"
    ADD CONSTRAINT delivery_id FOREIGN KEY (delivery_id) REFERENCES public."Deliveries"(delivery_id) NOT VALID;


--
-- Name: Sales location_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales"
    ADD CONSTRAINT location_id FOREIGN KEY (location_id) REFERENCES public."Locations"(location_id) NOT VALID;


--
-- Name: Sales salesrep_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Sales"
    ADD CONSTRAINT salesrep_id FOREIGN KEY (salesrep_id) REFERENCES public."SalesReps"(salesrep_id) NOT VALID;


--
-- PostgreSQL database dump complete
--

