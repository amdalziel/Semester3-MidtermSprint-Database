--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.1
-- Dumped by pg_dump version 16.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "BestKind";
--
-- Name: BestKind; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "BestKind" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'C';


ALTER DATABASE "BestKind" OWNER TO postgres;

\connect "BestKind"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: calculate_reward_points(); Type: FUNCTION; Schema: public; Owner: postgres
--

CREATE FUNCTION public.calculate_reward_points() RETURNS trigger
    LANGUAGE plpgsql
    AS $_$
BEGIN
    -- Calculate reward points as 10 points for every $100 spent
    NEW.RewardPoints := floor(NEW.amountspent / 100) * 10;
    RETURN NEW;
END;
$_$;


ALTER FUNCTION public.calculate_reward_points() OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: beerdelivered; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.beerdelivered (
    beerdeliveredid integer NOT NULL,
    deliveryid integer NOT NULL,
    beerid integer NOT NULL,
    quantitydelivered integer NOT NULL
);


ALTER TABLE public.beerdelivered OWNER TO postgres;

--
-- Name: beerdelivered_beerdeliveredid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.beerdelivered_beerdeliveredid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.beerdelivered_beerdeliveredid_seq OWNER TO postgres;

--
-- Name: beerdelivered_beerdeliveredid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.beerdelivered_beerdeliveredid_seq OWNED BY public.beerdelivered.beerdeliveredid;


--
-- Name: beers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.beers (
    beerid integer NOT NULL,
    name character varying(255) NOT NULL,
    category character varying(255) NOT NULL,
    pricesingle numeric NOT NULL,
    pricebucket numeric NOT NULL
);


ALTER TABLE public.beers OWNER TO postgres;

--
-- Name: beers_beerid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.beers_beerid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.beers_beerid_seq OWNER TO postgres;

--
-- Name: beers_beerid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.beers_beerid_seq OWNED BY public.beers.beerid;


--
-- Name: customerrewards; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customerrewards (
    rewardid integer NOT NULL,
    customerid integer NOT NULL,
    amountspent numeric NOT NULL,
    rewardpoints integer NOT NULL
);


ALTER TABLE public.customerrewards OWNER TO postgres;

--
-- Name: customerrewards_rewardid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customerrewards_rewardid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customerrewards_rewardid_seq OWNER TO postgres;

--
-- Name: customerrewards_rewardid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customerrewards_rewardid_seq OWNED BY public.customerrewards.rewardid;


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    customerid integer NOT NULL,
    name character varying(255) NOT NULL,
    email character varying(255),
    phone character varying(50),
    address text,
    created_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_customerid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.customers_customerid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.customers_customerid_seq OWNER TO postgres;

--
-- Name: customers_customerid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.customers_customerid_seq OWNED BY public.customers.customerid;


--
-- Name: deliveries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.deliveries (
    deliveryid integer NOT NULL,
    date date NOT NULL,
    recyclingcansweight numeric,
    recyclingbucketsweight numeric
);


ALTER TABLE public.deliveries OWNER TO postgres;

--
-- Name: deliveries_deliveryid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.deliveries_deliveryid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.deliveries_deliveryid_seq OWNER TO postgres;

--
-- Name: deliveries_deliveryid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.deliveries_deliveryid_seq OWNED BY public.deliveries.deliveryid;


--
-- Name: locations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.locations (
    locationid integer NOT NULL,
    name character varying(255) NOT NULL,
    type character varying(50) NOT NULL
);


ALTER TABLE public.locations OWNER TO postgres;

--
-- Name: locations_locationid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.locations_locationid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.locations_locationid_seq OWNER TO postgres;

--
-- Name: locations_locationid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.locations_locationid_seq OWNED BY public.locations.locationid;


--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    saleid integer NOT NULL,
    beerid integer NOT NULL,
    salesrepid integer NOT NULL,
    locationid integer NOT NULL,
    saleamount numeric NOT NULL,
    saledate date NOT NULL,
    customerid integer
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- Name: sales_saleid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.sales_saleid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.sales_saleid_seq OWNER TO postgres;

--
-- Name: sales_saleid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.sales_saleid_seq OWNED BY public.sales.saleid;


--
-- Name: salesreps; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.salesreps (
    salesrepid integer NOT NULL,
    name character varying(255) NOT NULL,
    totalsales numeric NOT NULL,
    awards character varying(255)
);


ALTER TABLE public.salesreps OWNER TO postgres;

--
-- Name: salesreps_salesrepid_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.salesreps_salesrepid_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.salesreps_salesrepid_seq OWNER TO postgres;

--
-- Name: salesreps_salesrepid_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.salesreps_salesrepid_seq OWNED BY public.salesreps.salesrepid;


--
-- Name: beerdelivered beerdeliveredid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beerdelivered ALTER COLUMN beerdeliveredid SET DEFAULT nextval('public.beerdelivered_beerdeliveredid_seq'::regclass);


--
-- Name: beers beerid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beers ALTER COLUMN beerid SET DEFAULT nextval('public.beers_beerid_seq'::regclass);


--
-- Name: customerrewards rewardid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customerrewards ALTER COLUMN rewardid SET DEFAULT nextval('public.customerrewards_rewardid_seq'::regclass);


--
-- Name: customers customerid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers ALTER COLUMN customerid SET DEFAULT nextval('public.customers_customerid_seq'::regclass);


--
-- Name: deliveries deliveryid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliveries ALTER COLUMN deliveryid SET DEFAULT nextval('public.deliveries_deliveryid_seq'::regclass);


--
-- Name: locations locationid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations ALTER COLUMN locationid SET DEFAULT nextval('public.locations_locationid_seq'::regclass);


--
-- Name: sales saleid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales ALTER COLUMN saleid SET DEFAULT nextval('public.sales_saleid_seq'::regclass);


--
-- Name: salesreps salesrepid; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesreps ALTER COLUMN salesrepid SET DEFAULT nextval('public.salesreps_salesrepid_seq'::regclass);


--
-- Data for Name: beerdelivered; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.beerdelivered (beerdeliveredid, deliveryid, beerid, quantitydelivered) FROM stdin;
\.
COPY public.beerdelivered (beerdeliveredid, deliveryid, beerid, quantitydelivered) FROM '$$PATH$$/3664.dat';

--
-- Data for Name: beers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.beers (beerid, name, category, pricesingle, pricebucket) FROM stdin;
\.
COPY public.beers (beerid, name, category, pricesingle, pricebucket) FROM '$$PATH$$/3656.dat';

--
-- Data for Name: customerrewards; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customerrewards (rewardid, customerid, amountspent, rewardpoints) FROM stdin;
\.
COPY public.customerrewards (rewardid, customerid, amountspent, rewardpoints) FROM '$$PATH$$/3670.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (customerid, name, email, phone, address, created_at) FROM stdin;
\.
COPY public.customers (customerid, name, email, phone, address, created_at) FROM '$$PATH$$/3668.dat';

--
-- Data for Name: deliveries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.deliveries (deliveryid, date, recyclingcansweight, recyclingbucketsweight) FROM stdin;
\.
COPY public.deliveries (deliveryid, date, recyclingcansweight, recyclingbucketsweight) FROM '$$PATH$$/3662.dat';

--
-- Data for Name: locations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.locations (locationid, name, type) FROM stdin;
\.
COPY public.locations (locationid, name, type) FROM '$$PATH$$/3666.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (saleid, beerid, salesrepid, locationid, saleamount, saledate, customerid) FROM stdin;
\.
COPY public.sales (saleid, beerid, salesrepid, locationid, saleamount, saledate, customerid) FROM '$$PATH$$/3658.dat';

--
-- Data for Name: salesreps; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.salesreps (salesrepid, name, totalsales, awards) FROM stdin;
\.
COPY public.salesreps (salesrepid, name, totalsales, awards) FROM '$$PATH$$/3660.dat';

--
-- Name: beerdelivered_beerdeliveredid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.beerdelivered_beerdeliveredid_seq', 1, false);


--
-- Name: beers_beerid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.beers_beerid_seq', 10, true);


--
-- Name: customerrewards_rewardid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customerrewards_rewardid_seq', 1, false);


--
-- Name: customers_customerid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_customerid_seq', 22, true);


--
-- Name: deliveries_deliveryid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.deliveries_deliveryid_seq', 1, false);


--
-- Name: locations_locationid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.locations_locationid_seq', 7, true);


--
-- Name: sales_saleid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_saleid_seq', 1, false);


--
-- Name: salesreps_salesrepid_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.salesreps_salesrepid_seq', 7, true);


--
-- Name: beerdelivered beerdelivered_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beerdelivered
    ADD CONSTRAINT beerdelivered_pkey PRIMARY KEY (beerdeliveredid);


--
-- Name: beers beers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beers
    ADD CONSTRAINT beers_pkey PRIMARY KEY (beerid);


--
-- Name: customerrewards customerrewards_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customerrewards
    ADD CONSTRAINT customerrewards_pkey PRIMARY KEY (rewardid);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (customerid);


--
-- Name: deliveries deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.deliveries
    ADD CONSTRAINT deliveries_pkey PRIMARY KEY (deliveryid);


--
-- Name: locations locations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.locations
    ADD CONSTRAINT locations_pkey PRIMARY KEY (locationid);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (saleid);


--
-- Name: salesreps salesreps_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.salesreps
    ADD CONSTRAINT salesreps_pkey PRIMARY KEY (salesrepid);


--
-- Name: customerrewards trigger_calculate_reward_points; Type: TRIGGER; Schema: public; Owner: postgres
--

CREATE TRIGGER trigger_calculate_reward_points BEFORE INSERT OR UPDATE ON public.customerrewards FOR EACH ROW EXECUTE FUNCTION public.calculate_reward_points();


--
-- Name: beerdelivered fk_beerdelivered_beerid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beerdelivered
    ADD CONSTRAINT fk_beerdelivered_beerid FOREIGN KEY (beerid) REFERENCES public.beers(beerid);


--
-- Name: beerdelivered fk_beerdelivered_deliveryid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.beerdelivered
    ADD CONSTRAINT fk_beerdelivered_deliveryid FOREIGN KEY (deliveryid) REFERENCES public.deliveries(deliveryid);


--
-- Name: customerrewards fk_customerrewards_customerid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customerrewards
    ADD CONSTRAINT fk_customerrewards_customerid FOREIGN KEY (customerid) REFERENCES public.customers(customerid);


--
-- Name: sales fk_sales_beerid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT fk_sales_beerid FOREIGN KEY (beerid) REFERENCES public.beers(beerid);


--
-- Name: sales fk_sales_customerid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT fk_sales_customerid FOREIGN KEY (customerid) REFERENCES public.customers(customerid);


--
-- Name: sales fk_sales_locationid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT fk_sales_locationid FOREIGN KEY (locationid) REFERENCES public.locations(locationid);


--
-- Name: sales fk_sales_salesrepid; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT fk_sales_salesrepid FOREIGN KEY (salesrepid) REFERENCES public.salesreps(salesrepid);


--
-- PostgreSQL database dump complete
--

